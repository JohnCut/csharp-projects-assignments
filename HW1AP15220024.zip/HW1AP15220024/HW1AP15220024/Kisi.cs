﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleApplication14
{
    class Kisi
    {
        //Kişi sınıfı özellikleri tanımlandı.
        public string adi;
        public string soyadi;

        //Kişi sınıfı kurucu metodu.
        public Kisi(string ad, string soyad)
        {
            adi = ad;
            soyadi = soyad;
        }


    }
}
